﻿using System;
using System.Net.Mail;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("LocalHost");

            mail.From = new MailAddress("bwhite@Hypervwinseven2.com");
            mail.To.Add("bwhite@flowfocus.com");
            mail.Subject = "Test Mail";
            mail.Body = "This is for testing SMTP mail from IIS";

            SmtpServer.Port = 25;
            SmtpServer.Credentials = new System.Net.NetworkCredential("username", "password");
            //SmtpServer.EnableSsl = true;

            SmtpServer.Send(mail);

        }
    }
}
