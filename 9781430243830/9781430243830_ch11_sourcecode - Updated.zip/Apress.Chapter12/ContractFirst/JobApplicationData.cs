﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ContractFirst
{
    public class JobApplication
    {
        public Guid JobApplicationId { get; set; }
        public JobApplication SubmittedApplication { get; set; }
        public bool PassedInterview { get; set; }
        public bool PassedBackgroundCheck { get; set; }
        public JobPosting JobAppliedTo { get; set; }
        public Candidate ApplyingCandidate { get; set; }
    }

    public class Feedback
    {
        public Candidate ApplyingCandidate { get; set; }
        public string ApplicationFeedback { get; set; }
    }
    public class BackgroundCheck
    {
        public Candidate ApplyingCandidate { get; set; }
        public DateTime BackgroundCheckDate { get; set; }
    }
    public class Candidate
    {
        public int CandidateId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
        public string SSN { get; set; }
    }

    public class JobPosting
    {
        public int JobPostingId { get; set; }
        public string PositionName { get; set; }
        public DateTime PostingDate { get; set; }
        public Manager HiringManager { get; set; }
    }

    public class Manager
    {
        public int ManagerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailAddress { get; set; }
    }

}