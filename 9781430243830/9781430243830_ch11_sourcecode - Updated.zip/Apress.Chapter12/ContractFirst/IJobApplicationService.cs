﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;

namespace ContractFirst
{
    [ServiceContract]
    public interface IJobApplicationService
    {
       [OperationContract(IsOneWay=true)]
       void ApplyForJob(JobApplication application);
       [OperationContract]   
       bool PerformBackgroundCheck(BackgroundCheck CandidateBackground);
       [OperationContract]
       bool EmailCandidateFeedBack(Feedback feedback);
       [OperationContract]   
       bool InterviewCandidate(Manager manager,Candidate candidate);
       [OperationContract]
       bool HireEmployee(JobApplication application);
    }

    
}