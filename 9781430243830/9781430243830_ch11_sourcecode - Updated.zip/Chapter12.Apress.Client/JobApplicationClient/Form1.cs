﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobPostingClient
{
    public partial class Form1 : Form
    {
        private JobPostingService.JobApplicationClient jobApplicationService = null;
            
        private string JobApplicationRef = string.Empty;

        public Form1()
        {
            InitializeComponent();
            jobApplicationService = new JobPostingService.JobApplicationClient();
        }

        private void cmdCreateApplication_Click(object sender, EventArgs e)
        {
            var application =
                new JobPostingService.JobApplication()
            {
                ApplyingCandidate = new JobPostingService.Candidate
                {
                    FirstName = "Jim",
                    LastName = "Smith",
                    EmailAddress = "jim.smith@acme.com",
                    SSN = "555-45-4444"
                },
                JobPostingId = 5
            };

            JobApplicationRef = jobApplicationService.ApplyForJob(application);
        }

        private void cmdCheckStatus_Click(object sender, EventArgs e)
        {
            try
            {
                var application = jobApplicationService.GetJobApplicationStatus(JobApplicationRef);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmdInterviewFeedback_Click(object sender, EventArgs e)
        {
            try
            {
                jobApplicationService.InterviewCandidate(JobApplicationRef, chkPassedInterview.Checked);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void PerformBackground()
        {
           // var backgroundCheck = new JobPostingClient.ServiceReference1.BackgroundCheckServiceClient();
           //var ret =  backgroundCheck.PerformBackgroundCheck("444-44-4444");
        }

        private void cmdCompleteProcess_Click(object sender, EventArgs e)
        {
            try
            {
                jobApplicationService.TerminateJobApplication(JobApplicationRef);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
