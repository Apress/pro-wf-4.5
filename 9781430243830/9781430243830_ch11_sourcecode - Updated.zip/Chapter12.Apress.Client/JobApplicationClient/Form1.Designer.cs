﻿namespace JobPostingClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdCreateApplication = new System.Windows.Forms.Button();
            this.cmdCheckStatus = new System.Windows.Forms.Button();
            this.cmdInterviewFeedback = new System.Windows.Forms.Button();
            this.chkPassedInterview = new System.Windows.Forms.CheckBox();
            this.cmdCompleteProcess = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdCreateApplication
            // 
            this.cmdCreateApplication.Location = new System.Drawing.Point(77, 42);
            this.cmdCreateApplication.Name = "cmdCreateApplication";
            this.cmdCreateApplication.Size = new System.Drawing.Size(137, 23);
            this.cmdCreateApplication.TabIndex = 0;
            this.cmdCreateApplication.Text = "Create Job Application";
            this.cmdCreateApplication.UseVisualStyleBackColor = true;
            this.cmdCreateApplication.Click += new System.EventHandler(this.cmdCreateApplication_Click);
            // 
            // cmdCheckStatus
            // 
            this.cmdCheckStatus.Location = new System.Drawing.Point(87, 148);
            this.cmdCheckStatus.Name = "cmdCheckStatus";
            this.cmdCheckStatus.Size = new System.Drawing.Size(113, 23);
            this.cmdCheckStatus.TabIndex = 1;
            this.cmdCheckStatus.Text = "Check Status";
            this.cmdCheckStatus.UseVisualStyleBackColor = true;
            this.cmdCheckStatus.Click += new System.EventHandler(this.cmdCheckStatus_Click);
            // 
            // cmdInterviewFeedback
            // 
            this.cmdInterviewFeedback.Location = new System.Drawing.Point(77, 106);
            this.cmdInterviewFeedback.Name = "cmdInterviewFeedback";
            this.cmdInterviewFeedback.Size = new System.Drawing.Size(137, 23);
            this.cmdInterviewFeedback.TabIndex = 2;
            this.cmdInterviewFeedback.Text = "Interview Feedback";
            this.cmdInterviewFeedback.UseVisualStyleBackColor = true;
            this.cmdInterviewFeedback.Click += new System.EventHandler(this.cmdInterviewFeedback_Click);
            // 
            // chkPassedInterview
            // 
            this.chkPassedInterview.AutoSize = true;
            this.chkPassedInterview.Location = new System.Drawing.Point(77, 83);
            this.chkPassedInterview.Name = "chkPassedInterview";
            this.chkPassedInterview.Size = new System.Drawing.Size(107, 17);
            this.chkPassedInterview.TabIndex = 4;
            this.chkPassedInterview.Text = "Passed Interview";
            this.chkPassedInterview.UseVisualStyleBackColor = true;
            // 
            // cmdCompleteProcess
            // 
            this.cmdCompleteProcess.Location = new System.Drawing.Point(197, 227);
            this.cmdCompleteProcess.Name = "cmdCompleteProcess";
            this.cmdCompleteProcess.Size = new System.Drawing.Size(75, 23);
            this.cmdCompleteProcess.TabIndex = 5;
            this.cmdCompleteProcess.Text = "Complete Job Application";
            this.cmdCompleteProcess.UseVisualStyleBackColor = true;
            this.cmdCompleteProcess.Click += new System.EventHandler(this.cmdCompleteProcess_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.cmdCompleteProcess);
            this.Controls.Add(this.chkPassedInterview);
            this.Controls.Add(this.cmdInterviewFeedback);
            this.Controls.Add(this.cmdCheckStatus);
            this.Controls.Add(this.cmdCreateApplication);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdCreateApplication;
        private System.Windows.Forms.Button cmdCheckStatus;
        private System.Windows.Forms.Button cmdInterviewFeedback;
        private System.Windows.Forms.CheckBox chkPassedInterview;
        private System.Windows.Forms.Button cmdCompleteProcess;
    }
}

