﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.Collections.Generic;

namespace Chapter3.Activities
{

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Activity workflow1 = new ApplicationExceptionWorkflow();
                var wfArgs = new Dictionary<string, object> { { "argInSeconds", 0 } };
                WorkflowInvoker.Invoke(workflow1, wfArgs);
            }
            catch(ApplicationException ex)
            {
                Console.WriteLine(string.Format("Application Exception --{0}-- has fired!", ex.Message));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception {0} has been bubbled up!", ex.Message);
            }
            finally
            {
                Console.ReadKey();
            }
        }
    }
}
