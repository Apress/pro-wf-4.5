﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace Chapter3.Activities
{

    public sealed class ExceptionActivity : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new ApplicationException("Here is an Application Exception!");
        }
    }
}
