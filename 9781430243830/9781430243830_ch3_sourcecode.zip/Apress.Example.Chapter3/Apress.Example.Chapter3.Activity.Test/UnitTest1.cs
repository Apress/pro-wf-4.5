﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System.Activities.XamlIntegration;
using System.Activities;

namespace Apress.Example.Chapter3.Activity.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var act = ActivityXamlServices.Load(@"C:\Users\bwhite\Documents\FlowFocus\Apress\Chapter3\Solution\Apress.Example.Chapter3\Apress.Example.Chapter3\bin\Debug\Workflow1.xaml");
            var retArg = WorkflowInvoker.Invoke(act, new Dictionary<string, object> 
            { 
                { "argAdd1", 3 }, 
                { "argAdd2", 5 } 
            });
            var result = Convert.ToInt32(retArg["AdditionResult"]);

            Assert.AreEqual(result, 3 + 5);
        }

        [TestMethod]
        public void TestMethod2()
        {
            Assert.AreNotEqual(new List<string>(), new System.Text.StringBuilder());
        }

        [TestMethod]
        public void TestMethod3()
        {
            Assert.AreEqual("123", "123");
        }
        [TestMethod]
        public void DoSomeThing()
        {
            System.Text.StringBuilder strBldr = null;
            try
            {
                DoSomeThingElse();
            }
            catch (Exception)
            {
                string str = "exception";
                strBldr.Append("Hello");
                
            }
            finally
            {
                Console.Write("from Finally");
            }
        }

        private void DoSomeThingElse()
        {
            try
            {
                throw new NotImplementedException("Not Implemented");
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
