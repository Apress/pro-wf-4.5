﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.Activities.Statements;
using Microsoft.VisualBasic.Activities;

namespace Apress.Example.Chapter3
{
    public partial class ImperativeCodeWorkflow
    {
        public void AdditionActivity()
        {
            Variable<int> Add1 = new Variable<int>
            {
                Name = "Add1",
                 Default = 5
            };

            Variable<int> Add2 = new Variable<int>
            {
                Name = "Add2",
                Default=5
            };

            Variable<int> Sum = new Variable<int>
            {
                Name = "Sum"
            };
            Activity wfSequence = new Sequence
            {
                Variables = { Add1,Add2,Sum },
                Activities =
                {
                    new Assign<int>
                    {
                        To = Sum,
                        Value = new VisualBasicValue<int>("Add1+Add2")
                    },
                    new WriteLine
                    {
                        Text = new InArgument<string>((env) =>string.Format("The sum of {0} and {1} is {2} ",Add1.Get(env),Add1.Get(env),Sum.Get(env)))
                    }
                }
            };

            WorkflowInvoker.Invoke(wfSequence);
        }
    }
}
