﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.Activities.Statements;
using Microsoft.VisualBasic.Activities;
using System.Activities.Expressions;

namespace Apress.Example.Chapter3
{
    public partial class DynamicCodeActivity
    {
        public Activity AdditionActivity()
        {
            var argAdd1 = new InArgument<int>();
            var argAdd2 = new InArgument<int>();
            var AdditionResult = new OutArgument<int>();

            Variable<int> varAdd1 = new Variable<int>
            {
                Name = "varAdd1",
                 Default = 5
            };

            Variable<int> varAdd2 = new Variable<int>
            {
                Name = "varAdd2",
                Default=5
            };
            

            var MathAddActivity = new DynamicActivity()
            {
                DisplayName = "Add two Integers",
                Properties = 
                {
                    new DynamicActivityProperty
                    {
                        Name = "argAdd1",
                        Type = typeof(InArgument<int>),
                        Value = argAdd1
                    },
                    new DynamicActivityProperty
                    {
                        Name = "argAdd2",
                        Type = typeof(InArgument<int>),
                        Value = argAdd2
                    },
                    new DynamicActivityProperty
                    {
                        Name = "AdditionResult",
                        Type = typeof(OutArgument<int>),
                        Value = AdditionResult
                    }
                },
                Implementation = () => new Sequence
                {
                    Variables = 
                    { 
                        varAdd1, 
                        varAdd2
                    },
                    Activities =
                    {
                        new Assign<int>
                        {
                            To = varAdd1,
                            Value = new ArgumentValue<int>
                            { 
                                ArgumentName = "argAdd1"
                            }
                        },
                        new Assign<int>
                        {
                            To = varAdd2,
                            Value = new ArgumentValue<int> 
                            { 
                                ArgumentName = "argAdd2"
                            }
                        },
                        new Assign<int>
                        {
                            To = new ArgumentReference<int> 
                            {
                                ArgumentName = "AdditionResult"
                            },
                            Value = new VisualBasicValue<int>("varAdd1+varAdd2")
                        },
                        new WriteLine
                        {
                            Text = new InArgument<string>((env) =>string.Format("The sum of {0} and {1} is {2} "
                                ,varAdd1.Get(env)
                                ,varAdd2.Get(env)
                                ,AdditionResult.Get(env)))
                        }
                    }
                }
            };
            return MathAddActivity;
        }
    }
}
