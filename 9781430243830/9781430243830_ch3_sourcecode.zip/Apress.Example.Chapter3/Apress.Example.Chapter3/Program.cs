﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Activities.XamlIntegration;

namespace Apress.Example.Chapter3
{

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                WorkflowInvoker.Invoke(new Apress.Example.Chapter3.Listing3_11());
            }
            catch (Exception)
            {
                throw;
            }
            Console.ReadKey();
        }

        private static void CallDynamicAdditionActivity()
        {
            var dynamicActivity = new DynamicCodeActivity();
            var actAddition = dynamicActivity.AdditionActivity();

            var result = WorkflowInvoker.Invoke(actAddition,
                new Dictionary<string, object> { { "argAdd1", 3 }, { "argAdd2", 5 } });

            Console.WriteLine(string.Format("The workflow returned {0}", result["AdditionResult"]));
            Console.ReadKey();

            var imperativeCode = new ImperativeCodeWorkflow();
            imperativeCode.AdditionActivity();
        }
        
        private static void CallImperativeCodeAdditionActivity()
        {
            var imperativeCode = new ImperativeCodeWorkflow();
            imperativeCode.AdditionActivity();   
        }

        private static void CallXAMLAdditionActivity()
        {
            var act = ActivityXamlServices.Load(@"Workflow1.xaml");
            var retArg = WorkflowInvoker.Invoke(act, new Dictionary<string, object> 
            { 
                { "argAdd1", 3 }, 
                { "argAdd2", 5 } 
            });
            var result = Convert.ToInt32(retArg["AdditionResult"]);
        }

       
    }
}
