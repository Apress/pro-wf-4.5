﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.Activities.Statements;

namespace Apress.Example.Chapter3
{
   public partial class ImperativeCodeWorkflow
    {
       public void SimpleHelloWorld()
       {
           Activity wfActivity = new WriteLine
            {
                Text = "Hello from Workflow."
            };
           WorkflowInvoker.Invoke(wfActivity);
       }
    }
}
