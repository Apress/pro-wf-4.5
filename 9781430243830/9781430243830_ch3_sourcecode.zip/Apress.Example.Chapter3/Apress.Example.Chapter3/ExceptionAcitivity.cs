﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;

namespace Apress.Example.Chapter3
{

    public sealed class ExceptionActivity : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            throw new Exception("Here is an exception");
        }
    }
}
