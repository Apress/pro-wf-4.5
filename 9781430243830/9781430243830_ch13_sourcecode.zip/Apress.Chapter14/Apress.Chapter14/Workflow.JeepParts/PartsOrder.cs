﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Workflow.JeepParts
{
    public class PartsOrder
    {
        public Guid OrderId { get; set; }
        public List<OrderLineItem> OrderLineItems { get; set; }
    }

    public class OrderLineItem
    {
        public int LineItemId { get; set; }
        public int OrderId { get; set; }
        public int PartId { get; set; }
    }

    public class JeepPart
    {
        public int PartId { get; set; }
        public string PartName { get; set; }
    }
}