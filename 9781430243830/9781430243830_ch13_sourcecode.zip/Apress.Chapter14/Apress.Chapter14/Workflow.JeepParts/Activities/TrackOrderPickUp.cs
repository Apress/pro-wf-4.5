﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Activities.Tracking;

namespace Workflow.JeepParts
{
    public class TrackOrderPickup : CodeActivity
    {
        protected override void Execute(CodeActivityContext context)
        {
            var record = new CustomTrackingRecord("WorkingLevel")
            {
                Data = 
                                {
                                    {"OrderId", context.WorkflowInstanceId},
                                    {"DateTimePickedUp", DateTime.Now}
                                }
            };

            context.Track(record);
        }
    }
}