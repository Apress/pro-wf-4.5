﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JeepPartsClient
{
    public partial class Form1 : Form
    {
        protected PartsService.JeepPartsServiceClient partsService;
        protected Guid? OrderId = null;

        public Form1()
        {
            InitializeComponent();
             partsService = new PartsService.JeepPartsServiceClient("BasicHttpBinding_IJeepPartsService");
        }

        private void cmdOrderParts_Click(object sender, EventArgs e)
        {
            try
            {
                
                OrderId = partsService.CreateOrder(
                    new PartsService.PartsOrder
                    {
                        OrderLineItems =
                        new List<PartsService.OrderLineItem>
                        {
                            new PartsService.OrderLineItem{ LineItemId = 1},
                            new PartsService.OrderLineItem{ LineItemId = 2}
                        }
                    }
                );
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmdPickedUp_Click(object sender, EventArgs e)
        {
            partsService.PickedUpOrder(OrderId.Value);
        }

    }
}
