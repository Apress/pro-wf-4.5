﻿namespace JeepPartsClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdOrderParts = new System.Windows.Forms.Button();
            this.cmdPickedUp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdOrderParts
            // 
            this.cmdOrderParts.Location = new System.Drawing.Point(108, 227);
            this.cmdOrderParts.Name = "cmdOrderParts";
            this.cmdOrderParts.Size = new System.Drawing.Size(75, 23);
            this.cmdOrderParts.TabIndex = 0;
            this.cmdOrderParts.Text = "Create Order";
            this.cmdOrderParts.UseVisualStyleBackColor = true;
            this.cmdOrderParts.Click += new System.EventHandler(this.cmdOrderParts_Click);
            // 
            // cmdPickedUp
            // 
            this.cmdPickedUp.Location = new System.Drawing.Point(189, 227);
            this.cmdPickedUp.Name = "cmdPickedUp";
            this.cmdPickedUp.Size = new System.Drawing.Size(93, 23);
            this.cmdPickedUp.TabIndex = 1;
            this.cmdPickedUp.Text = "PickedUp Order";
            this.cmdPickedUp.UseVisualStyleBackColor = true;
            this.cmdPickedUp.Click += new System.EventHandler(this.cmdPickedUp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.cmdPickedUp);
            this.Controls.Add(this.cmdOrderParts);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdOrderParts;
        private System.Windows.Forms.Button cmdPickedUp;
    }
}

