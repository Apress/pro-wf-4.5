﻿//------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Xaml;
using System.Xml;
using System.Xml.Linq;
using Microsoft.Activities.Design.ExpressionTranslation;
using Microsoft.Activities.Messaging;
using Microsoft.Workflow.Client;
using System.Linq;

namespace UsingWorkflowTools
{
    public class Helper
    {
        const int REQUEST_TIMEOUT = 30;

        public static string PublishWorkflow(Uri baseUri, string scopeName, string activityFile,
            string activityName, string workflowName, bool startWorkflow, Dictionary<string, object> filters)
        {
            WorkflowManagementClient managementClient = CreateManagementClient(baseUri, scopeName);
            string errorMessage = PublishActivity(managementClient, baseUri, scopeName, activityFile, activityName);

            if (!string.IsNullOrEmpty(errorMessage))
            {
                return errorMessage;
            }

            WorkflowDescription workflowDescription = new WorkflowDescription()
            {
                Name = workflowName,
                ActivityPath = activityName,

            };

            if (filters != null)
            {
                MatchAllSubscriptionFilter filterActivity = new MatchAllSubscriptionFilter();
                foreach (var filter in filters)
                {
                    filterActivity.Matches.Add(filter);
                }
                workflowDescription.ActivationFilter = filterActivity;
            }
           
            try
            {
                managementClient.Workflows.Publish(workflowDescription);
            }
            catch (Exception e)
            {
                return "Failed to publish workflow: " + e.Message;
            }

            if (startWorkflow)
            {
                try
                {
                    ClientSettings clientSettings = GetClientSettings();
                    WorkflowInstanceManager instanceManager = new WorkflowInstanceManager(baseUri, clientSettings);
                    instanceManager.StartWorkflow(workflowDescription.Name, new WorkflowStartInfo());

                }
                catch (Exception e)
                {
                    return "Failed to start workflow: " + e.Message;
                }
            }
            return string.Empty;
        }

        static ClientSettings GetClientSettings()
        {
            return new ClientSettings()
            {
                Credentials = CredentialCache.DefaultNetworkCredentials,
                RequestTimeout = TimeSpan.FromSeconds(REQUEST_TIMEOUT)
            };
        }

        static WorkflowManagementClient CreateManagementClient(Uri baseUri, string scopeName)
        {
            ClientSettings clientSettings = GetClientSettings();
            WorkflowManagementClient managementClient = new WorkflowManagementClient(baseUri, clientSettings);
            
            // Will create a new scope if not already exists)
            managementClient.CurrentScope.PublishChildScope(scopeName, new ScopeInfo());

            return managementClient;
        }

        static string PublishActivity(WorkflowManagementClient managementClient, Uri baseUri,
            string scopeName, string activityFile, string activityName)
        {
            string activityString = File.ReadAllText(activityFile);
            string translatedFolder = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(activityFile)), @"bin\Debug\TranslatedWorkflows");
            string translatedXamlFile = Directory.GetFiles(translatedFolder, "*.xaml").First();
            string translatedXamlString = File.ReadAllText(translatedXamlFile);

            if (translatedXamlString.StartsWith("Error"))
            {
                return translatedXamlString;
            }

            ActivityDescription activityDesc = new ActivityDescription();
            activityDesc.Name = activityName; // This has to match the Activity Class name when publish activity.
            activityDesc.Xaml = XElement.Parse(translatedXamlString);

            try
            {
                managementClient.Activities.Publish(activityDesc);
            }
            catch (Exception e)
            {
                return "Failed to publish activity: " + e.Message;
            }

            return string.Empty;
        }

    }
}
