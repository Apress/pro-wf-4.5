﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------

namespace UsingWorkflowTools
{
    class Program
    {
        static void Main(string[] args)
        {

            // Must match the name in x:class of the activity, e.g.<Activity mc:Ignorable="sap sap2010 sads" x:Class="ActivityLibrary.Activity1" 
            const string activityName = "ActivityLibrary.Activity1";
         
            // Activity source file
            const string sourceFile = @"..\..\..\ActivityLibrary\Activity1.xaml";
           
            // Workflow Server address (or TestServiceHost's listening's address for debugging)
            const string scopeUri = "http://localhost:12291/";
            
            // Indicating whether workflow should be started once published.
            const bool autoStartWorkflow = true;

            // Notes:
            // - A workflow can only reference activities published within the same scope or in its parent scope. 
            //   It cannot reference activities published in the children scopes.
            // - Workflows/activities published under the root scope (“/”) are not supported. It is recommended
            //   that workflows/activities are published to a non-root scope (e.g.  “/Scope1”).
            // - A new scope will be created automatically.
            const string scope = "/Scope1";

            // Workflow name
            const string workflowName = "MyWorkflow";

            // Defines the filter that is used to match incoming messages(on the Scope's notification endpoint) to 
            // the workflow instance. Note that this filter does an exact match on each of the properties specified 
            // to the value that is provided. Note: the type defined is relevant to the matching semantics, that is 
            // an int of 1 would not match a string “1” in the published message.
            // Note: A notification can be published by WorkflowClientManagement.PublishNotification(WorkflowNotiofication)
            Dictionary<string, object> activationFilters = new Dictionary<string, object>();

            // Publish a workflow to the server (or TestServiceHost for debugging)
            string errorMessage = Helper.PublishWorkflow(new Uri(scopeUri), scope,
                        sourceFile, activityName, workflowName, autoStartWorkflow, activationFilters);

            Console.WriteLine(errorMessage);
        }
    }
}
