﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Collections.ObjectModel;

namespace Apress.Chapter13.DataModel
{
    public class Customer
    {
        public Customer()
        {
            CustomerPawns = new Collection<CustomerPawn>();
        }
        [Key]
        public int CustomerId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string OwnersSSN { get; set; }
        [Required]
        public string DriversLicenseNumber { get; set; }
        [Required]
        public DateTime DOB { get; set; }

        public virtual  ICollection<CustomerPawn> CustomerPawns { get; set; }
    }
}
