﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace Apress.Chapter13.DataModel
{
    public sealed class Pawning : DbContext
    {
        public DbSet<CustomerPawn> CustomerPawns { get; set; }
        public DbSet<PawnedItem> PawnedItems { get; set; }
        public DbSet<Customer> Customers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerPawn>()
                .HasMany<PawnedItem>(ItemsPawned => ItemsPawned.PawnedItems);

            modelBuilder.Entity<PawnedItem>()
                .HasKey(p => new { p.CustomerPawnId, p.PawnedItemId });

            modelBuilder.Entity<Customer>()
                .HasMany<CustomerPawn>(pawnedItems => pawnedItems.CustomerPawns);
        }
    }
}
