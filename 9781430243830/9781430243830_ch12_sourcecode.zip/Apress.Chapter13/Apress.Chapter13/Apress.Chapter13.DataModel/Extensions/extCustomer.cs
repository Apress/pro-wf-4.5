﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace Apress.Chapter13.DataModel
{
    public static class extCustomer
    {
        public static string ToJson(this Customer customer)
        {
            using (var ms = new MemoryStream())
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(Customer));
                serializer.WriteObject(ms, customer);
                ms.Position = 0;
                return new StreamReader(ms).ReadToEnd();
            }
        }

        public static object FromJson(this string Json)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(Customer));
            var retCustomer = 
                serializer.ReadObject(new MemoryStream(Encoding.Default.GetBytes(Json)));
            return retCustomer;
        }
    }
}
