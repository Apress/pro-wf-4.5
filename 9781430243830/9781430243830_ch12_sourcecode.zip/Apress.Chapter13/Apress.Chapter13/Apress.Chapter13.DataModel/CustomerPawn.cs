﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Collections.ObjectModel;

namespace Apress.Chapter13.DataModel
{
    public class CustomerPawn
    {
        public CustomerPawn()
        {
            PawnedItems = new Collection<PawnedItem>();
        }

        [Key]
        public int CustomerPawnId { get; set; }
        [Required]
        public int CustomerId { get; set; }
        [Required]
        public virtual ICollection<PawnedItem> PawnedItems { get; set; }

    }
}
