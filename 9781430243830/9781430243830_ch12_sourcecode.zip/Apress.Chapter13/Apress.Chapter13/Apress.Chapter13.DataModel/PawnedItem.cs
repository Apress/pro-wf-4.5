﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Apress.Chapter13.DataModel
{
    public class PawnedItem
    {
        public PawnedItem()
        {
            DatePawned = DateTime.Now;
        }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PawnedItemId { get; set; }
        [Key]
        public int CustomerPawnId { get; set; }
        [Required]
        public string ModelNumber { get; set; }
        [Required]
        public string ItemName { get; set; }
        [Required]
        public decimal PawnedAmount { get; set; }
        public DateTime DatePawned { get; set; }
    }
}
