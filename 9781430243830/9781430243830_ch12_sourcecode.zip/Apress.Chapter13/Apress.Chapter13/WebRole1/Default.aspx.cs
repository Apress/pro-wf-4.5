﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Apress.Chapter13.DataModel;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace WebRole1
{
    public partial class _Default : Page
    {
        //private const string QueueName = "customerqueue";
        //private CloudStorageAccount StorageAccount = null;

        //private CloudQueue InitiateAzureQueue()
        //{
        //    CloudQueue CustomerQueue = null;
        //    try
        //    {
        //        StorageAccount =
        //        CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString"));
        //        var queueClient = StorageAccount.CreateCloudQueueClient();

        //        CustomerQueue =
        //        queueClient.GetQueueReference(QueueName);
        //        CustomerQueue.CreateIfNotExist();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return CustomerQueue;
        //}
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void cmdSubmit_Click(object sender, EventArgs e)
        {
            var pawnService = new PawnSvc.PawnServiceClient();
            
            try
            {
                var customer = new Customer
                {
                    DOB = Convert.ToDateTime(txtDOB.Text),
                    DriversLicenseNumber = txtDriverLicense.Text,
                    FirstName = txtFirstName.Text,
                    LastName = txtLastName.Text,
                    OwnersSSN = txtSSN.Text,
                    CustomerPawns = new List<CustomerPawn>
                   {
                        new CustomerPawn()
                        {
                            PawnedItems = new List<PawnedItem>
                            {
                                new PawnedItem{
                                    ItemName = txtItemName.Text,
                                    PawnedAmount = Convert.ToDecimal(txtAmount.Text),
                                    ModelNumber = txtModelNumber.Text
                                }
                            }
                        }
                   }
                };

                

                lblAppResults.Text = pawnService.CreateCustomerApplication(customer);

                //string connectionString = CloudConfigurationManager.GetSetting("Microsoft.ServiceBus.ConnectionString");
                //var client = QueueClient.CreateFromConnectionString(connectionString, "PawnQueue");
                //var brokerMessage = new BrokeredMessage(customer);
                //client.Send(brokerMessage);
                
                //Setting up the Azure Queue
                //var customerQueue = InitiateAzureQueue();
                //var newMessage = new CloudQueueMessage(customer.ToJson());
                //customerQueue.AddMessage(newMessage);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void cmdApprove_Click(object sender, EventArgs e)
        {
            try
            {
                var pawnService = new PawnSvc.PawnServiceClient();
                pawnService.ApproveCustomer(txtSSN.Text,chkApprove.Checked);
            }
            catch (Exception)
            {
                
                throw;
            }
        }
    }
}