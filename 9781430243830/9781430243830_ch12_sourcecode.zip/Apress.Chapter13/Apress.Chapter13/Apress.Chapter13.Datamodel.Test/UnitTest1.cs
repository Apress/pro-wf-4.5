﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.Entity;
using System.Collections.ObjectModel;
using System.Collections.Generic;


namespace Apress.Chapter13.DataModel.Test
{
    [TestClass]
    public class UnitTest1
    {
        //[TestInitialize]
        //public void TestMethod1()
        //{
        //    Database.SetInitializer(
        //         new DropCreateDatabaseAlways<Pawning>());

        //    using (var pawning = new Pawning())
        //    {
        //        pawning.Database.Initialize(false);
        //    }
        //}

        [TestMethod]
        public void LoadWorkflowInBlob()
        {

        }
        [TestMethod]
        public void PawnAnItem()
        {
            using (var pawning = new Pawning())
            {
                var customer = new Customer()
                {
                    DOB = Convert.ToDateTime("10/14/1972"),
                    DriversLicenseNumber = "84fdf8945",
                    FirstName = "Bayer",
                    LastName = "White",
                    OwnersSSN = "234-34-2345",
                    CustomerPawns = new List<CustomerPawn>
                   {
                        new CustomerPawn()
                        {
                            PawnedItems = new List<PawnedItem>
                            {
                                new PawnedItem{
                                    ItemName = "Car",
                                    PawnedAmount = 475.50m,
                                    ModelNumber = "12345fsfe"
                                }
                            }
                        },
                        new CustomerPawn()
                        {
                            PawnedItems = new List<PawnedItem>
                            {
                                new PawnedItem{
                                    ItemName = "Bird",
                                    PawnedAmount = 3.50m,
                                    ModelNumber = "1fda45fsfe"
                                }
                            }
                        }
                   }
                };
                pawning.Customers.Add(customer);
                pawning.SaveChanges();
            }
        }
    }
}
