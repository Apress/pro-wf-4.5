using System;
using System.Activities;
using System.Activities.XamlIntegration;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using Apress.Chapter13.DataModel;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;

namespace WorkerRole1
{
    public class WorkerRole : RoleEntryPoint
    {
        private const string QueueName = "customerqueue";
        private CloudStorageAccount StorageAccount = null;

        public override void Run()
        {
            // This is a sample worker implementation. Replace with your logic.
            Trace.WriteLine("WorkerRole1 entry point called", "Information");

            Trace.WriteLine("Initiating storage account", "Information");
            StorageAccount =
                CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString"));
            var customerQueue = InitiateAzureQueue();
            var blobContainer = InitiateBlobStorage();
            
            while (true)
            {
                try
                {

                    var wfData = customerQueue.GetMessage();
                    if (wfData == null)
                    {
                        Thread.Sleep(10000);
                        Trace.WriteLine("No message in queue! Waiting 10 seconds...", "Information");
                    }
                    else
                    {
                        try
                        {
                            var newBlob = blobContainer.GetBlobReference("PawnShopWorkflow.xaml");
                            //newBlob.Delete();
                            var ms = new System.IO.MemoryStream();
                            newBlob.DownloadToStream(ms);
                            ms.Position = 0;

                            var activity = ActivityXamlServices.Load(ms);

                            var newCustomer = wfData.AsString.FromJson() as Customer;
                            //var activity = new Apress.Chapter13.WF.ProcessPawnedItems();
                            
                            var inargs =
                                new Dictionary<string, object> { { "argNewCustomer", newCustomer } };
                            WorkflowInvoker wfInvoker = new WorkflowInvoker(activity);
                            try
                            {
                                var args = wfInvoker.Invoke(inargs);

                                if (!string.IsNullOrEmpty(args["argResponse"].ToString()))
                                    Trace.WriteLine(args["argResponse"]);
                            }
                            catch (Exception ex)
                            {
                                Trace.WriteLine(ex.Message, "Information");
                            }
                            
                            customerQueue.DeleteMessage(wfData);
                            Trace.WriteLine("Processed Message!", "Information");

                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message,"Exception");
                }
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.

            return base.OnStart();
        }

        private CloudQueue InitiateAzureQueue()
        {
            CloudQueue CustomerQueue = null;
            try
            {
                var queueClient = StorageAccount.CreateCloudQueueClient();

                CustomerQueue =
                queueClient.GetQueueReference(QueueName);
                CustomerQueue.CreateIfNotExist();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CustomerQueue;
        }
        private CloudBlobContainer InitiateBlobStorage()
        {
            CloudBlobContainer blobContainer = null;
            try
            {
                var StorageAccount =
                CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString"));



                var blobClient = StorageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference("workflows");
                blobClient.RetryPolicy = RetryPolicies.Retry(3, TimeSpan.FromSeconds(5));
                
                if (blobContainer.CreateIfNotExist())
                {
                    var permissions = new BlobContainerPermissions() { PublicAccess = BlobContainerPublicAccessType.Blob };
                    blobContainer.SetPermissions(permissions);
                }

                return blobContainer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
