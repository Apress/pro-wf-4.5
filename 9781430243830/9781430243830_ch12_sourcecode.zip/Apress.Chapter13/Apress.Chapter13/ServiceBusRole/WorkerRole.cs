﻿using System;
using System.Activities;
using System.Activities.XamlIntegration;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using Apress.Chapter13.DataModel;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;

namespace ServiceBusRole
{
    public class WorkerRole : RoleEntryPoint
    {
        // The name of your queue
        const string QueueName = "PawnQueue";

        // QueueClient is thread-safe. Recommended that you cache 
        // rather than recreating it on every request
        QueueClient Client;
        bool IsStopped;

        public override void Run()
        {
            var blobContainer = InitiateBlobStorage();

            while (!IsStopped)
            {
                try
                {
                    // Receive the message
                    BrokeredMessage receivedMessage = null;
                    receivedMessage = Client.Receive();

                    if (receivedMessage != null)
                    {
                        var newBlob = blobContainer.GetBlobReference("PawnShopWorkflow.xaml");
                        //newBlob.Delete();
                        var ms = new System.IO.MemoryStream();
                        newBlob.DownloadToStream(ms);
                        ms.Position = 0;

                        var activity = ActivityXamlServices.Load(ms);

                        var newCustomer = receivedMessage.GetBody<Customer>();
                        //var activity = new Apress.Chapter13.WF.ProcessPawnedItems();

                        var inargs =
                            new Dictionary<string, object> { { "argNewCustomer", newCustomer } };
                        WorkflowInvoker wfInvoker = new WorkflowInvoker(activity);
                        try
                        {
                            var args = wfInvoker.Invoke(inargs);

                            if (args["argResponse"]!=null)
                                Trace.WriteLine(args["argResponse"]);
                        }
                        catch (Exception ex)
                        {
                            Trace.WriteLine(ex.Message, "Information");
                        }
                        // Process the message
                        Trace.WriteLine("Processing", receivedMessage.SequenceNumber.ToString());
                        receivedMessage.Complete();
                    }
                }
                catch (MessagingException e)
                {
                    if (!e.IsTransient)
                    {
                        Trace.WriteLine(e.Message);
                        throw;
                    }

                    Thread.Sleep(10000);
                }
                catch (OperationCanceledException e)
                {
                    if (!IsStopped)
                    {
                        Trace.WriteLine(e.Message);
                        throw;
                    }
                }
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            // Create the queue if it does not exist already
            string connectionString = CloudConfigurationManager.GetSetting("Microsoft.ServiceBus.ConnectionString");
            var namespaceManager = NamespaceManager.CreateFromConnectionString(connectionString);
            if (!namespaceManager.QueueExists(QueueName))
            {
                namespaceManager.CreateQueue(QueueName);
            }

            // Initialize the connection to Service Bus Queue
            Client = QueueClient.CreateFromConnectionString(connectionString, QueueName);
            IsStopped = false;
            return base.OnStart();
        }

        public override void OnStop()
        {
            // Close the connection to Service Bus Queue
            IsStopped = true;
            Client.Close();
            base.OnStop();
        }

        private CloudBlobContainer InitiateBlobStorage()
        {
            CloudBlobContainer blobContainer = null;
            try
            {
                var StorageAccount =
                CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString"));

                var blobClient = StorageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference("workflows");
                blobClient.RetryPolicy = RetryPolicies.Retry(3, TimeSpan.FromSeconds(5));

                if (blobContainer.CreateIfNotExist())
                {
                    var permissions = new BlobContainerPermissions() { PublicAccess = BlobContainerPublicAccessType.Blob };
                    blobContainer.SetPermissions(permissions);
                }

                return blobContainer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
