﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using Apress.Chapter13.DataModel;

namespace Apress.Chapter13.DataModel
{

    public sealed class SaveCustomer : CodeActivity<bool>
    {
        public InArgument<Customer> NewCustomer { get; set; }

        protected override bool Execute(CodeActivityContext context)
        {
            bool retVal = false;
            try
            {
                var newCustomer = context.GetValue(this.NewCustomer);

                using (var pawning = new Pawning())
                {
                    pawning.Customers.Add(newCustomer);
                    pawning.SaveChanges();
                }
                retVal = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return retVal;
        }
    }
}
