﻿using System;
using System.Text;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Chapter6.DataModel;
using System.Data.Entity;
using System.Linq;


namespace Chapter6.Testing
{
    [TestClass]
    public class UnitTest1
    {
        
        [TestMethod]
        public void TestGetOrders()
        {
            using (var ordering = new Ordering())
            {
                var custs = from cust in ordering.Customers
                             select cust;

                var customers = new Collection<Customer>();
                foreach (var c in custs)
                {
                    customers.Add(c);
                }
            }
        }

        [TestMethod]
        public void TestCodeFirst()
        {

            Database.SetInitializer(
                 new DropCreateDatabaseAlways<Ordering>());

            using (var ordering = new Ordering())
            {
                ordering.Database.Initialize(false);
                var customer = new Customer
                {
                    FirstName = "John"
                    ,
                    LastName = "Smith"
                };

                var order =
                    new Order 
                    { 
                        DateOrdered = DateTime.Now,
                        ShippingState = "Florida"
                    };

                order.LineItems.Add(new OrderLineItem
                        {
                            LineDescription = "Widget 1",
                            Price = 5.50m,
                            SKU = "fff-321-gfsf"
                        });
                order.LineItems.Add(new OrderLineItem
                        {
                            LineDescription = "Widget 2",
                            Price = 4.10m,
                            SKU = "AAA-234-asdf"
                        });

                order.LineItems.Add(new OrderLineItem
                {
                    LineDescription = "Widget 3",
                    Price = 10.10m,
                    SKU = "BBB-321-j7df"
                });
                customer.CustomerOrders.Add(order);
                ordering.Customers.Add(customer);

                ordering.SaveChanges();
            }
            
        }
    }
}
