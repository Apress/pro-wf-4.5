﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Chapter6.DataModel;
using Exercise2;

namespace wpfHost
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private WorkflowApplication wfApp;
        public MainWindow()
        {
            InitializeComponent();
            cmdApprove.IsEnabled = false;
        }


        private UnhandledExceptionAction OnUnhandledException(WorkflowApplicationUnhandledExceptionEventArgs uh)
        {
            return UnhandledExceptionAction.Terminate;
        }

        /// <summary>
        /// The on workflow completed.
        /// </summary>
        /// <param name="wc">
        /// The event args
        /// </param>
        private void OnWorkflowIdle(WorkflowApplicationIdleEventArgs iw)
        {
            cmdApprove.IsEnabled = true;
        }
        /// <summary>
        /// The on workflow completed.
        /// </summary>
        /// <param name="wc">
        /// The event args
        /// </param>
        private void OnWorkflowCompleted(WorkflowApplicationCompletedEventArgs wc)
        {
            foreach (var arg in wc.Outputs)
            {
                if (arg.Key.Equals("argOutCustomers"))
                {
                    var customers = arg.Value as Customers;
                    foreach (var cust in customers)
                    {
                        foreach (var order in cust.CustomerOrders)
                        {
                            MessageBox.Show(string.Format(" Approved: {2}, Total Order Price: {0} with Tax: {1}", string.Format("{0:C}", order.TotalPrice),string.Format("{0:C}", order.Tax),order.OrderApproved.ToString()));
                        }
                    }
                }
                cmdRuntime.IsEnabled = true;
                    
            }
        }

        private void cmdRuntime_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Activity workflow = new wfCommunication();
                wfApp = new WorkflowApplication(workflow);
                wfApp.SynchronizationContext = SynchronizationContext.Current;
                wfApp.OnUnhandledException = OnUnhandledException;
                wfApp.Completed = OnWorkflowCompleted;
                wfApp.Idle = OnWorkflowIdle;
                wfApp.Run();
                
                cmdRuntime.IsEnabled = false;
                
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void cmdApprove_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                wfApp.ResumeBookmark("ApproveOrder",chkApprove.IsChecked);
                cmdApprove.IsEnabled = false;
            }
            catch (Exception ex)
            {
                
                throw;
            }
        }
    }
}
