﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;

namespace Exercise1
{

    class Program
    {
        static void Main(string[] args)
        {
            // Create and cache the workflow definition
            Activity workflow1 = new wfCustomerOrders();
            WorkflowInvoker.Invoke(workflow1);
            Console.ReadKey();
        }
    }
}
