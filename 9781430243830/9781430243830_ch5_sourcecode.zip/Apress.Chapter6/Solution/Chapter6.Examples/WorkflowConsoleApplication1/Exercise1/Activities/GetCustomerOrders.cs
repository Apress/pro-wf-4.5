﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Chapter6.DataModel;
using System.Collections.ObjectModel;

namespace Exercise1.Activities
{
    public class GetCustomerOrders:CodeActivity
    {
        [RequiredArgument]
        public OutArgument<Customers> outCustomers { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var customers = new Customers();
            using (var db = new Ordering())
            {
                db.Configuration.LazyLoadingEnabled = false;
                var custs = db.Customers.Include("CustomerOrders.LineItems");

                
                foreach (var c in custs)
                {
                    customers.Add(c);
                }
                // Reassign the argument.
                context.SetValue(outCustomers, customers);
            }
        }
    }
}
