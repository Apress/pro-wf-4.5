﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Chapter6.DataModel
{
    public class Order
    {
        public Order()
        {
            LineItems = new Collection<OrderLineItem>();
        }
        [Key]
        public int OrderId { get; set; }
        [Required]
        public int CustomerId { get; set; }
        [Required]
        public DateTime DateOrdered { get; set; }
        [Required]
        public string ShippingState { get; set; }
        [Required]
        public virtual ICollection<OrderLineItem> LineItems { get; set; }
        [NotMapped]
        public decimal Tax { get; set; }
        [NotMapped]
        public decimal TotalPrice { get; set; }
        [NotMapped]
        public bool? OrderApproved { get; set; }
    }
}
