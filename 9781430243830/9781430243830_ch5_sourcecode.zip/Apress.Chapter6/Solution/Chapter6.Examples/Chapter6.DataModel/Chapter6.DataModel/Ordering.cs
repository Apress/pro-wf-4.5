﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Chapter6.DataModel
{
    public sealed class Ordering : DbContext
    {
        public DbSet<Order> Orders { get; set; }
        public DbSet<Customer> Customers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Customer can have many Orders.
            modelBuilder.Entity<Customer>()
                .HasMany<Order>(customer => customer.CustomerOrders);
            
            // Order can have many LineItems.
            modelBuilder.Entity<Order>()
                .HasMany<OrderLineItem>(order => order.LineItems);

            // LineItems contains a composite key.
            modelBuilder.Entity<OrderLineItem>()
                .HasKey(p => new { p.OrderId, p.LineItemId });


        }

    }
}
