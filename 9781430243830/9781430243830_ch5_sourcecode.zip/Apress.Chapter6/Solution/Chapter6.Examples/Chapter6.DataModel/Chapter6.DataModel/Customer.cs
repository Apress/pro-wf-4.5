﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Chapter6.DataModel
{
    public class Customer
    {
        public Customer()
        {
            CustomerOrders = new Collection<Order>();
        }
        [Key]
        public int CustomerId { get; set; }
        public string CCNumber { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        public virtual ICollection<Order> CustomerOrders { get; set; }
    }

    public class Customers : Collection<Customer>
    {

    }
}
