﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Chapter6.DataModel
{
    public class OrderLineItem
    {
        
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LineItemId { get; set; }
        [Key]
        public int OrderId { get; set; }
        [Required]
        public string LineDescription { get; set; }
        [Required]
        public string SKU { get; set; }
        [Required]
        public Decimal? Price { get; set; }
    }

}
