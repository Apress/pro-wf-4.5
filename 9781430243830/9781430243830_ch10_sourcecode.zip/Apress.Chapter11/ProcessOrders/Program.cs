﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.Activities.XamlIntegration;
using Chapter11.Model;


namespace ProcessOrders
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] products =  
                new string[] 
                {
                    "Widget1",
                    "Widget2",
                    "Widget3",
                    "Widget4",
                    "Widget5"
                };
            decimal[] prices = 
                new decimal[] 
                {
                    5.40m,
                    10.25m,
                    2.00m,
                    4.30m,
                    6.45m
                };

            Console.WriteLine("Starting Order Processor...");

            while (1 == 1)
            {
                var rand = new Random();
                var currentIndex = rand.Next(0, 4);
                Console.WriteLine("Order for {0}, costing {1}"
                    , products[currentIndex]
                    , string.Format("{0:C}", prices[currentIndex]));

                System.Threading.Thread.Sleep(3000);
                GetLatestWorkflow(
                    new Order
                            {
                                Price = prices[currentIndex],
                                Product = products[currentIndex]
                            });
            }
        }

        private static void GetLatestWorkflow(Order processedOrder)
        {
            string wfPath
                = @"C:\Users\bwhite\Documents\Visual Studio 11\Projects\Apress.Chapter11\Example1\Example1\bin\Debug\CreatedWorkflows\";
            try
            {
                var dirInfo = new DirectoryInfo(wfPath);
                var latestWF = (from wfFile in dirInfo.GetFiles()
                                orderby wfFile.LastWriteTime descending
                                select wfFile.Name).FirstOrDefault();

                if (!string.IsNullOrWhiteSpace(latestWF))
                {
                    var wf
                        = ActivityXamlServices.Load(wfPath + latestWF);

                    WorkflowInvoker.Invoke(wf, new Dictionary<string, object>() { { "inArgNewOrder", processedOrder } });
                }

                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
