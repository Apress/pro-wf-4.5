﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Activities.Core.Presentation;
using System.Activities.Presentation;
using System.Activities.Presentation.Toolbox;
using System.Activities.Statements;


namespace Exercise1
{
    /// <summary>
    /// Interaction logic for RehostingWFDesigner.xaml
    /// </summary>
    public partial class RehostedWFDesigner : Window
    {
        private WorkflowDesigner wfDesigner;

        public RehostedWFDesigner()
        {
            InitializeComponent();

            //Register WF designer metadata
            var WFDesignerMetaData = new DesignerMetadata();
            WFDesignerMetaData.Register();
            
            BuildDesigner();
            BuildWFToolbox();
            AddWFPropertyWindow();
        }

        private void BuildDesigner()
        {
            //instantiates the designer
            wfDesigner = new WorkflowDesigner();
            //places the designer within the column 
            //with an index of 1
            Grid.SetColumn(this.wfDesigner.View, 1);
            //Loads a default Sequence activity as the first
            //activity for the workflow

            wfDesigner.Context.Services.GetService<DesignerConfigurationService>().AnnotationEnabled = true;
            wfDesigner.Context.Services.GetService<DesignerConfigurationService>().TargetFrameworkName = new
             System.Runtime.Versioning.FrameworkName(".NET Framework", new Version(4, 5));

            wfDesigner.Load(new Sequence());
            //shows a re-hosted declaritive workflow
            //that can be changed
            MainGrid1.Children.Add(this.wfDesigner.View);

            

        }

        private void BuildWFToolbox()
        {
            var WFToolbox = new ToolboxControl();

            //set the category for the re-hosted activities
            ToolboxCategory category = new ToolboxCategory("Native Activities");

            //Add an if activity
            var act1 =
                new ToolboxItemWrapper("System.Activities.Statements.If",
                typeof(If).Assembly.FullName, null,
                "If");
            //Add a WriteLine activity
            var act2 =
                new ToolboxItemWrapper("System.Activities.Statements.WriteLine",
                typeof(WriteLine).Assembly.FullName, null, "WriteLine");
            //Add a DoWhile activity
            var act3 =
                new ToolboxItemWrapper("System.Activities.Statements.DoWhile",
                typeof(DoWhile).Assembly.FullName, null, "DoWhile");
            //Add an Assign activity
            var act4 =
                new ToolboxItemWrapper("System.Activities.Statements.Assign",
                typeof(Assign).Assembly.FullName, null, "Assign");

            //Add the activities under the new category, "Native Activities"
            category.Add(act1);
            category.Add(act2);
            category.Add(act3);
            category.Add(act4);

            //Add the category to the toolbox
            WFToolbox.Categories.Add(category);
            
            //Add the toolbox to the grid column that has a 0 index.
            Grid.SetColumn(WFToolbox, 0);
            //Show the WF toolbox 
            MainGrid1.Children.Add(WFToolbox);
        }
        
        private void AddWFPropertyWindow()
        {
            Grid.SetColumn(wfDesigner.PropertyInspectorView, 2);
            MainGrid1.Children.Add(wfDesigner.PropertyInspectorView);
        }

    }
}
