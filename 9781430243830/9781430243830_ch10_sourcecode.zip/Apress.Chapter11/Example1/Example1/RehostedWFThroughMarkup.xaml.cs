﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Activities.Core.Presentation;
using System.Activities.Presentation;
using System.Activities.Statements;

using System.Activities;
using System.IO;

using Microsoft.VisualBasic.Activities;
using System.Activities.Presentation.View;
using Chapter11.Model;

namespace Exercise1
{
    /// <summary>
    /// Interaction logic for RehostedWFThroughMarkup2.xaml
    /// </summary>
    public partial class RehostedWFThroughMarkup : Window
    {
        const string WorkflowFolder = "\\CreatedWorkflows\\";
        WorkflowDesigner _wd = null;
        
        public RehostedWFThroughMarkup()
        {
            InitializeComponent();
        }

        private void BuildNewDesigner()
        {//Designer must be instantiated each time a workflow is laoded

            try
            {
                _wd = new WorkflowDesigner();

                _wd.Context.Services.GetService<DesignerConfigurationService>().AnnotationEnabled = true;
                _wd.Context.Services.GetService<DesignerConfigurationService>().TargetFrameworkName = new
                 System.Runtime.Versioning.FrameworkName(".NET Framework", new Version(4, 5));
                //_wd.Load(wf);
                //_wd.Context.Services.GetService<DesignerView>().WorkflowShellBarItemVisibility =  ShellBarItemVisibility.None;
                PropertyBorder.Child = _wd.PropertyInspectorView;
                DesignerTab.Content = _wd.View;
                WFOutline.Child = _wd.OutlineView; // Adds the Outline View

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            // registering metadata
            (new DesignerMetadata()).Register();
        }

        private void DesignerXamlTabDeck_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabControl tabs = (TabControl)sender;

            if (tabs.SelectedContent == null)
                return;

            if (tabs.SelectedIndex == 1)
            {
                string tempFile = System.IO.Path.GetTempFileName();
                try
                {
                    _wd.Save(tempFile);
                    XamlEditor.Text = File.ReadAllText(tempFile);
                }
                finally
                {
                    File.Delete(tempFile);
                }
            }
        }

        private ActivityBuilder BuildBaseActivity()
        {
            try
            {
                ActivityBuilder builder = new ActivityBuilder
                {

                    Name = txtWorkflowName.Text!=string.Empty?txtWorkflowName.Text:txtWorkflowName.Text,
                    Implementation = new Flowchart(),
                    Properties = 
                    {
                        new DynamicActivityProperty
                        {
                             Name = "inArgNewOrder",
                             Type = typeof(InArgument<Order>),
                             Attributes = 
                             {
                                 new RequiredArgumentAttribute(), 
                             },
                             Value = new InArgument<Order>()
                        }
                    }
                };

                return builder;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void cmdNew_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (txtWorkflowName.Text.Length == 0)
                    txtWorkflowName.Text = "CustomWorkflow";
                
                BuildNewDesigner();
                _wd.Load(BuildBaseActivity());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtWorkflowName.Text))
                {
                    if (_wd!=null)
                    {
                        _wd.Flush();
                        if (_wd.Text.Length>0)
                        {
                            var wfFile = Directory.GetCurrentDirectory() + WorkflowFolder + txtWorkflowName.Text + ".xaml";

                            if (!Directory.Exists(Directory.GetCurrentDirectory() + WorkflowFolder))
                                Directory.CreateDirectory(Directory.GetCurrentDirectory() + WorkflowFolder);
                            //else //Directory exists
                            //    File.OpenWrite(wfFile);
                            
                            _wd.Save(wfFile);
                        }
                    }
                    else
                        MessageBox.Show("Please press 'Create' to build a new workflow!");
                }
                else
                {
                    MessageBox.Show("Please enter a workflow name!");
                }
            } 
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmdDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtWorkflowName.Text))
                {
                    
                    var wfFile = Directory.GetCurrentDirectory() + WorkflowFolder + txtWorkflowName.Text + ".xaml";

                    if (!File.Exists(wfFile))
                        MessageBox.Show("Workflow does not exist!");
                    else
                    {
                        File.Delete(wfFile);
                        MessageBox.Show("Workflow has been removed!");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a workflow name!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmdLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtWorkflowName.Text))
                {

                    var wfFile = Directory.GetCurrentDirectory() + WorkflowFolder + txtWorkflowName.Text + ".xaml";

                    if (!File.Exists(wfFile))
                        MessageBox.Show("Workflow does not exist!");
                    else
                    {
                        BuildNewDesigner();
                        _wd.Load(wfFile);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a workflow name!");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
