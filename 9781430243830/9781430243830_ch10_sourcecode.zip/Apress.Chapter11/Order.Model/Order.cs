﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter11.Model
{
    public class Order
    {
        public string Product { get; set; }
        public decimal Price { get; set; }
    }
}
