﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.Collections.Generic;

namespace Apress.Chapter8.WF
{

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Activity workflow1 = new Workflow1();
                //var netSales = new Decimal();
                //var salesPercentage = new Decimal();

                //Console.WriteLine("Enter net sales: ");
                //try
                //{
                //    netSales = Convert.ToDecimal(Console.ReadLine());
                //}
                //catch (Exception)
                //{
                //    throw new ApplicationException("Net sales was not entered as a number!");
                //}

                //Console.WriteLine("Enter sales percentage: ");
                //try
                //{
                //    salesPercentage = Convert.ToDecimal(Console.ReadLine());
                //}
                //catch (Exception)
                //{
                //    throw new ApplicationException("Sales percentage was not entered as a number!");
                //}
                
                //var inArgs = new Dictionary<string, object>();
                //inArgs.Add("EnterNetSales", netSales);
                //inArgs.Add("EnterSalesPercentage", salesPercentage);
                //var arg = WorkflowInvoker.Invoke(workflow1, inArgs);
                //Console.WriteLine("Calculated commission is {0:C}", arg["returnSalesCommission"]);
                //Console.WriteLine("Press any key to end...");
                
               
                //var WFApp = new WorkflowApplication(CodeTest);
                //var WFApp1 = new WorkflowApplication(asyncTest);

                //WFApp.Run();
                //WFApp1.Run();


                //var CodeTest = new TestCode();
                //WorkflowInvoker.Invoke(CodeTest);
                //var asyncTest = new TestAsync();
                //WorkflowInvoker.Invoke(asyncTest);
                //Console.WriteLine("File content : {0}", arg["ReturnFileContent"]);
                //Console.WriteLine("File content : {0}", arg["ReturnFileContent"]);

                var testNative = new TestNative();
                WorkflowInvoker.Invoke(testNative);

                Console.Read();
            }
            catch(ApplicationException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Press any key to end...");
                Console.Read();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error has occured!");
                Console.WriteLine("Press any key to end...");
                Console.Read();
            }
            // Create and cache the workflow definition
            
        }
    }
}
