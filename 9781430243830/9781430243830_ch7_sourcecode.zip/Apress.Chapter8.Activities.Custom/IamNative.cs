﻿using System;
using System.Activities;
using System.Activities.Statements;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Apress.Chapter8.Activities.Custom;

namespace Apress.Chapter8.WF
{
    [Designer(typeof(IamNativeDesigner))]
    public sealed class IamNative:NativeActivity<bool>
    {
        //public Activity childActivity { get; set; }
        WriteLine childActivity { get; set; }
        Variable<string> WriteLineText;

        protected override void Execute(NativeActivityContext context)
        {
            context.ScheduleActivity(childActivity, ChildActivityCompleted);
        }
        protected override void CacheMetadata(NativeActivityMetadata metadata)
        {
            //base.CacheMetadata(metadata);
            metadata.AddChild(childActivity);
            metadata.AddImplementationVariable(WriteLineText);
            
            
        }

        void ChildActivityCompleted(NativeActivityContext context, ActivityInstance instance)
        {
            Console.WriteLine("WriteLine activity completed its execution!");
        }
    }
}
