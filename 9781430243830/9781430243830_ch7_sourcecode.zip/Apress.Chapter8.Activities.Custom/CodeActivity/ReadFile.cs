﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.IO;
using System.Threading;

namespace Apress.Chapter8.Activities.Custom
{
    public sealed class ReadFile : CodeActivity<string>
    {
        // Define an activity input argument of type string
        public InArgument<string> PathAndFile { get; set; }

        // If your activity returns a value, derive from CodeActivity<TResult>
        // and return the value from the Execute method.
        protected override string Execute(CodeActivityContext context)
        {
            // Obtain the runtime value of the Text input argument
            string pathFile = context.GetValue(this.PathAndFile);

            var fileText = File.ReadAllText(pathFile);
            Thread.Sleep(2000);

            return fileText;
        }
    }
}
