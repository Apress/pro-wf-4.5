﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Apress.Chapter8.Activities.Custom
{
    //public class SalesCommission:CodeActivity
    [Designer(typeof(SalesCommissionDesigner))]
    public class SalesCommission : CodeActivity<decimal>
    {
        [RequiredArgument]
        public InArgument<decimal> NetSales { get; set; }
        [RequiredArgument]
        public InArgument<decimal> Percentage { get; set; }

        public Activity ChildWriteLine { get; set; }

        //public decimal NetSales { get; set; }
        //public decimal Percentage { get; set; }

        //public OutArgument<decimal> CalculatedCommission { get; set; }

        protected override decimal Execute(CodeActivityContext context)
        {
            var sales = context.GetValue(NetSales);
            var salesPercentage = context.GetValue(Percentage);
            var commission = sales * (salesPercentage / 100);
            //var commission = NetSales * (Percentage / 100);
            //Console.WriteLine("For sales of {0:C} and sales percentage at {1}%, the sales commission is {2:C}", sales, salesPercentage, commission);
            //context.SetValue(CalculatedCommission, commission);
            return commission;
        }

        //protected override void CacheMetadata(CodeActivityMetadata metadata)
        //{
        //    base.CacheMetadata(metadata);

        //    if (NetSales <= 0)
        //        metadata.AddValidationError("Sales cannot be less than 0!");
        //    if (Percentage <= 0)
        //        metadata.AddValidationError("Sales percentgage cannot be less than 0!");
        //    else
        //    {
        //        if (Percentage > 20)
        //            metadata.AddValidationError(string.Format("Sales percentgage {0} cannot be greater than 20%", Percentage));
        //    }
        //}
    }
}
