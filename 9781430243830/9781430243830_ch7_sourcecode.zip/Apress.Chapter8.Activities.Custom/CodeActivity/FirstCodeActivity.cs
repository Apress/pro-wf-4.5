﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Apress.Chapter8.Activities.Custom
{
    public class FirstCodeActivity: CodeActivity
    {

        protected override void Execute(CodeActivityContext context)
        {
            Console.WriteLine("FirstCodeActivity has executed!");
        }
    }
}
