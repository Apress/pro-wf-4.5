﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.IO;
using System.Threading;

namespace Apress.Chapter8.WF
{

    public sealed class ReadFileAsync : AsyncCodeActivity<string>
    {
        // Define an activity input argument of type string
        public InArgument<string> PathAndFile { get; set; }

        protected override IAsyncResult BeginExecute(AsyncCodeActivityContext context, AsyncCallback callback, object state)
        {
            var filePath = context.GetValue(PathAndFile);
            Func<string,string> ReadFileDelegate = new Func<string,string>(ReadFile);
            context.UserState = ReadFileDelegate;
            Thread.Sleep(2000);
            return ReadFileDelegate.BeginInvoke(filePath,callback,state);
        }

        protected override string EndExecute(AsyncCodeActivityContext context, IAsyncResult result)
        {
            Func<string, string> ReadFileDelegate = (Func<string, string>)context.UserState;
            return Convert.ToString(ReadFileDelegate.EndInvoke(result));
        }

        string ReadFile(string FilePath)
        {
            var fileText = File.ReadAllText(FilePath);
            

            return fileText;
        }

    }
}
