﻿using System;
using System.Linq;
using System.Activities;
using System.Activities.Statements;
using System.Threading;

namespace Chapter4.StateMachine
{

    class Program
    {
        static void Main(string[] args)
        {
            AutoResetEvent autoEvent1 = new AutoResetEvent(false);
            AutoResetEvent autoEvent2 = new AutoResetEvent(false);
            // Create and cache the workflow definition
            Activity workflow1 = new Workflow1();
            WorkflowApplication wfApp =
                new WorkflowApplication(workflow1);
            

            wfApp.Completed = delegate(WorkflowApplicationCompletedEventArgs e)
            {
                Console.WriteLine("Workflow has completed!");
                autoEvent1.Set();
            };

            wfApp.Idle = delegate(WorkflowApplicationIdleEventArgs e)
            {
                autoEvent2.Set();
            };

            wfApp.Run();
            var retValu = 0;
            WaitHandle[] handles = new WaitHandle[] { autoEvent1, autoEvent2 };
            while (WaitHandle.WaitAny(handles) != 0)
            {
                retValu = Convert.ToInt32(Console.ReadLine());
                
                if(retValu==1)
                    wfApp.ResumeBookmark("BookmarkChildResponse", retValu);
                else
                    wfApp.ResumeBookmark("BookmarkResponse", retValu);
            }
        }

        // Create and cache the workflow definition
            
    }
}
