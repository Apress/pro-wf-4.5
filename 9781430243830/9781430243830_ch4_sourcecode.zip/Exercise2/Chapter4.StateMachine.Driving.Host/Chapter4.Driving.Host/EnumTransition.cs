﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4.Driving.Host
{
    public enum DriveTransition 
    {
        StartEngine,
        TurnOff,
        InGear,
        PutInReverse,
        PutInPark, 
    };

    //public enum DrivingState
    //{
    //    Park,
    //    Drive,
    //    Reverse,
    //    Neutral,
    //    TurnedOff
    //};
}
