﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chapter4.Driving.Host
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            StartWFRuntime();
        }

        private void cmdStartEngine_Click(object sender, RoutedEventArgs e)
        {
            StartEngine();
        }
        
        private void cmdDrive_Click(object sender, RoutedEventArgs e)
        {
            GoForward();
        }

        private void cmdPark_Click(object sender, RoutedEventArgs e)
        {
            PutInPark();
        }
        private void cmdReverse_Click(object sender, RoutedEventArgs e)
        {
            PutInReverse();
        }
        private void cmdTurnOff_Click(object sender, RoutedEventArgs e)
        {
            TurnOffEngine();
        }

        private static WorkflowApplication wfApp = null;
        /// <summary>
        ///   The workflow busy event.
        /// </summary>
        private AutoResetEvent workflowBusy = new AutoResetEvent(false);


        private void StartWFRuntime()
        {
            try
            {
                if (wfApp == null)
                {
                    wfApp = new WorkflowApplication(new wfDriving.Activity1());
                    wfApp.SynchronizationContext = SynchronizationContext.Current;
                    wfApp.OnUnhandledException = OnUnhandledException;
                    wfApp.Completed = OnWorkflowCompleted;
                    wfApp.Idle = OnWorkflowIdle;

                    wfApp.Run();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void PutInReverse()
        {
            try
            {
                ResumeBookmark("PutInReverse");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void PutInPark()
        {
            try
            {
                ResumeBookmark("PutInPark");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void GoForward()
        {
            try
            {
                ResumeBookmark("InGear");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void TurnOffEngine()
        {
            try
            {

                ResumeBookmark("TurnOff");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void StartEngine()
        {
            try
            {
                
                ResumeBookmark("StartEngine");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ResumeBookmark(string Bookmark)
        {
            try
            {
                wfApp.ResumeBookmark(Bookmark, string.Empty);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private UnhandledExceptionAction OnUnhandledException(WorkflowApplicationUnhandledExceptionEventArgs uh)
        {
            return UnhandledExceptionAction.Terminate;
        }

        /// <summary>
        /// The on workflow aborted.
        /// </summary>
        /// <param name="wa">
        /// The event args
        /// </param>
        private void OnWorkflowAborted(WorkflowApplicationAbortedEventArgs wa)
        {
            
        }

        /// <summary>
        /// The on workflow completed.
        /// </summary>
        /// <param name="wc">
        /// The event args
        /// </param>
        private void OnWorkflowCompleted(WorkflowApplicationCompletedEventArgs wc)
        {

            DisableButtons();
        }

        /// <summary>
        /// Called when the workflow is idle
        /// </summary>
        /// <param name="args">
        /// The event args.
        /// </param>
        private void OnWorkflowIdle(WorkflowApplicationIdleEventArgs args)
        {

            DisableButtons();
            foreach (var bk in args.Bookmarks)
            {
                DriveTransition ret;
                Enum.TryParse(bk.BookmarkName, out ret);
                switch (ret)
                {
                    case DriveTransition.InGear:
                        cmdDrive.IsEnabled = true;
                        break;
                    case DriveTransition.PutInPark:
                        cmdPark.IsEnabled = true;
                        break;
                    case DriveTransition.PutInReverse:
                        cmdReverse.IsEnabled = true;
                        break;
                    case DriveTransition.StartEngine:
                        cmdStartEngine.IsEnabled = true;
                        break;
                    case DriveTransition.TurnOff:
                        cmdTurnOff.IsEnabled = true;
                        break;
                }
            }
        }
        private void DisableButtons()
        {
            cmdDrive.IsEnabled = false;
            cmdPark.IsEnabled = false;
            cmdReverse.IsEnabled = false;
            cmdStartEngine.IsEnabled = false;
            cmdTurnOff.IsEnabled = false;
        }
    }
}
