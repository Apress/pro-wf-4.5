﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Activities;
using System.Threading;
using System.Runtime.DurableInstancing;
using System.Activities.DurableInstancing;
using System.Xml.Linq;
using WFPersistence.DataModel;
using Rental.DataModel;
using System.ServiceModel.Activities;
using ApressChapter9.Activities;



namespace RentalHost
{
    public partial class Form1 : Form,INotifyHost
    {
        private WorkflowApplication _wfApp;
        private SqlWorkflowInstanceStore _instanceStore;

        
         public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;
            CreatePersistenceStore();
            CreateInstanceStoreOwner();
            LoadInstancesIntoListView();
            cmdSetOwner.Enabled = false;
            
        }

         private void LoadInstancesIntoListView()
         {
             try
             {
                 var instances = 
                     GetPersistedInstances();
                 listView1.Items.Clear();

                 if (instances.Count > 0)
                 {

                     foreach (var instance in instances)
                     {
                         InitiateWorkflowRuntime();
                         _wfApp.Load(instance.InstanceId);
                         _wfApp.Run();
                         var item = new ListViewItem(
                         new string[3] 
                            {
                                _wfApp.Id.ToString(),
                                "Loaded",
                                "Not Overdue"
                    
                            });
                         listView1.Items.Add(item);
                     }
                 }
             }
             catch (Exception ex)
             {
                 throw;
             }
         }
        private UnhandledExceptionAction OnUnhandledException(WorkflowApplicationUnhandledExceptionEventArgs uh)
        {
            return UnhandledExceptionAction.Terminate;
        }

        private Instances GetPersistedInstances()
        {
            var PersistedWFInstances = new Instances();
            try
            {
                using (var PersistStore = new WFPersistenceStore())
                {
                    var result = from t in PersistStore.PersistedInstances
                                 select t;

                    foreach (var instance in result)
                    {
                        PersistedWFInstances.Add(
                        new Instance
                        {
                            InstanceId = instance.InstanceId,
                            PendingTimer = instance.PendingTimer,
                            CreationTime = instance.CreationTime,
                            LastUpdatedTime = instance.LastUpdatedTime,
                            ServiceDeploymentId = instance.ServiceDeploymentId,
                            SuspensionExceptionName = instance.SuspensionExceptionName,
                            SuspensionReason = instance.SuspensionReason,
                            ActiveBookmarks = instance.ActiveBookmarks,
                            CurrentMachine = instance.CurrentMachine,
                            LastMachine = instance.LastMachine,
                            ExecutionStatus = instance.ExecutionStatus,
                            IsInitialized = instance.IsInitialized,
                            IsSuspended = instance.IsSuspended,
                            IsCompleted = instance.IsCompleted,
                            EncodingOption = instance.EncodingOption,
                            ReadWritePrimitiveDataProperties = instance.ReadWritePrimitiveDataProperties,
                            WriteOnlyPrimitiveDataProperties = instance.WriteOnlyComplexDataProperties,
                            ReadWriteComplexDataProperties = instance.ReadWriteComplexDataProperties,
                            WriteOnlyComplexDataProperties = instance.WriteOnlyComplexDataProperties,
                            IdentityName = instance.IdentityName,
                            IdentityPackage = instance.IdentityPackage,
                            Build = instance.Build,
                            Major = instance.Major,
                            Minor = instance.Minor,
                            Revision = instance.Revision
                        });

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PersistedWFInstances;
        }

        /// <summary>
        /// The on workflow completed.
        /// </summary>
        /// <param name="wc">
        /// The event args
        /// </param>
        private void OnWorkflowIdle(WorkflowApplicationIdleEventArgs iw)
        {

        }
        /// <summary>
        /// The on workflow completed.
        /// </summary>
        /// <param name="wc">
        /// The event args
        /// </param>
        private void OnWorkflowCompleted(WorkflowApplicationCompletedEventArgs wc)
        {
            
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text == wc.InstanceId.ToString())
                    listView1.Items[item.Index].SubItems[1].Text = "Completed";

            }
        }
        private PersistableIdleAction OnWorkflowPersitableIdle(WorkflowApplicationIdleEventArgs ia)
        {
            return PersistableIdleAction.Persist;
        }

        private void InitiateWorkflowRuntime(Dictionary<string,object> WFArg=null)
        {
            try
            {
                Activity rentalWorkflow = new Exercise1.wfRentalEquipment();

                if(WFArg!=null)
                    _wfApp = new WorkflowApplication(rentalWorkflow, WFArg);
                else
                    _wfApp = new WorkflowApplication(rentalWorkflow);

                _wfApp.SynchronizationContext = SynchronizationContext.Current;
                _wfApp.OnUnhandledException = OnUnhandledException;
                _wfApp.Completed = OnWorkflowCompleted;
                _wfApp.Idle = OnWorkflowIdle;
                _wfApp.PersistableIdle = OnWorkflowPersitableIdle;
                _wfApp.InstanceStore = _instanceStore;
                _wfApp.Extensions.Add(this);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private EquipmentRental BuildWorkflowArg()
        {
            EquipmentRental rental = null;
            try
            {
                if (cboEquipment.SelectedIndex > 0)
                {
                    rental = new EquipmentRental();
                    rental.RentedEquipment =
                        new Equipment
                        {
                            DateRented = DateTime.Now,
                            EquipmentName = cboEquipment.SelectedItem.ToString(),
                            RentalMinutes = Convert.ToInt32(cboRentalMinutes.SelectedItem)
                        };
                }
            }
            catch (Exception)
            {
                
                throw;
            }
            return rental;
        }

        private void CreatePersistenceStore()
        {
            try
            {
                _instanceStore = new SqlWorkflowInstanceStore();
                _instanceStore.ConnectionString =
                    "Server=HYPERVWINSEVEN2;Database=WFPersist;Trusted_Connection=yes";
                _instanceStore.HostLockRenewalPeriod = TimeSpan.FromMinutes(5);
                
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private void CreateInstanceStoreOwner()
        {
            try
            {
                InstanceHandle handle = _instanceStore.CreateInstanceHandle();
                InstanceView view = _instanceStore.Execute(handle,
                                                new CreateWorkflowOwnerCommand(),
                                                TimeSpan.FromSeconds(30));

                handle.Free();
                _instanceStore.DefaultInstanceOwner = view.InstanceOwner;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void LoadNewRental()
        {
            try
            {
                var DateAndTimeRented = DateTime.Now.ToShortDateString()+" "+DateTime.Now.ToShortTimeString();
                var DateAndTimeDue = DateTime.Now.AddMinutes(Convert.ToInt32(cboRentalMinutes.SelectedItem));
                var Due = DateAndTimeDue.ToShortDateString()+" "+DateAndTimeDue.ToShortTimeString();

                var item = new ListViewItem(
                new string[3] 
                {
                    _wfApp.Id.ToString(),
                    "Started",
                    string.Format("Rented on {0} and due back by {1}"
                                ,DateAndTimeRented
                                ,Due)
                    
                });
                listView1.Items.Add(item);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void cmdCreateRental_Click(object sender, EventArgs e)
        {
            var rental = BuildWorkflowArg();
            if (rental != null)
            {
                Dictionary<string, object> wfArg = new Dictionary<string, object>(){
                        {
                            "argInRental",rental
                        }
                    };

                InitiateWorkflowRuntime(wfArg);
                _wfApp.Run();
                LoadNewRental();
            }
           
        }
        private void cmdUnloadInstances_Click(object sender, EventArgs e)
        {
            try
            {
                InstanceHandle handle = _instanceStore.CreateInstanceHandle();
                InstanceView view = _instanceStore.Execute(handle,
                                                new DeleteWorkflowOwnerCommand(),
                                                TimeSpan.FromSeconds(30));
                handle.Free();
                
                listView1.Items.Clear();
                cmdUnloadInstances.Enabled = false;
                cmdSetOwner.Enabled = true;
     
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        public void OverDueRental(string RentalStatus,Guid InstanceId)
        {
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text == InstanceId.ToString())
                {
                    listView1.Items[item.Index].SubItems[2].Text = RentalStatus;
                }
            }
        }

        private void cmdSetOwner_Click(object sender, EventArgs e)
        {
            try
            {
                CreatePersistenceStore();
                CreateInstanceStoreOwner();
                LoadInstancesIntoListView();
                cmdSetOwner.Enabled = false;
                cmdUnloadInstances.Enabled = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
