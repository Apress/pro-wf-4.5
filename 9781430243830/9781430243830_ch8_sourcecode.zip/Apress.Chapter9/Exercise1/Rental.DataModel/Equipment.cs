﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rental.DataModel
{
    [Serializable]
    public class Equipment
    {
        public int EquipmentId { get; set; }
        public string EquipmentName { get; set; }
        public decimal Price { get; set; }
        public DateTime DateRented { get; set; }
        public int RentalMinutes { get; set; }
        public DateTime ReturnedOn { get; set; }
    }
}
