﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rental.DataModel
{
    [Serializable]
    public class EquipmentRental
    {
        public int EquipmentId { get; set; }
        public int RentalId { get; set; }
        public Equipment RentedEquipment { get; set; }

    }
}
