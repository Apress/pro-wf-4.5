﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFPersistence.DataModel
{
    public class WFPersistenceStore : DbContext
    {
        public WFPersistenceStore()
            : base("WFPersist")
        {
        }

        public DbSet<Instance> PersistedInstances { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Instance>().ToTable("System.Activities.DurableInstancing.Instances");
        }
    }
}
