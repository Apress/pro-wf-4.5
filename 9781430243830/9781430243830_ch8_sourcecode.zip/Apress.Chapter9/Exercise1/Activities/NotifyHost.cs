﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Rental.DataModel;

namespace ApressChapter9.Activities
{
    public class NotifyHost : CodeActivity
    {
        [RequiredArgument]
        public InArgument<EquipmentRental> inRental { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            var rental = new EquipmentRental();
            rental = context.GetValue(inRental);
            INotifyHost host = context.GetExtension<INotifyHost>();
            if (rental.RentedEquipment.DateRented.AddMinutes(rental.RentedEquipment.RentalMinutes)<DateTime.Now)
                host.OverDueRental(string.Format("{0} rental is Overdue!",
                    rental.RentedEquipment.EquipmentName),
                    context.WorkflowInstanceId);
        }
    }
}
