﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApressChapter9.Activities
{
    public interface INotifyHost
    {
        void OverDueRental(string RentalStatus, Guid InstanceId);
    }
}
