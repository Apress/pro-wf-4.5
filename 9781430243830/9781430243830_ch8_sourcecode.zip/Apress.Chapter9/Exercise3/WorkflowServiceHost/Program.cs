﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Activities;
using System.Runtime.DurableInstancing;
using System.Activities.DurableInstancing;
using System.ServiceModel.Activities;

using Rental.DataModel;
using System.ServiceModel.Activities.Description;
using System.ServiceModel;


namespace ServiceHost
{
    class Program
    {
        [ServiceContract]
        public interface IEquipmentRental
        {
            [OperationContract( IsOneWay=false)]
            string CreateNewRental(EquipmentRental NewRental);
            [OperationContract(IsOneWay = false)]
            string RentalReturned(EquipmentRental CurrentRental);
            [OperationContract(IsOneWay = false)]
            string RentalReturnedLate(EquipmentRental LateRental);
        }

        const string hostAddress = "http://localhost:8080/EquipmentRentalService";
        static void Main(string[] args)
        {
            try
            {
                using (WorkflowServiceHost wfServiceHost
                    = new WorkflowServiceHost(new wfEquipmentRentalService.Activity1(), new Uri(hostAddress)))
                {
                    wfServiceHost.AddServiceEndpoint("IEquipmentRental", new BasicHttpBinding(), hostAddress);
                    Console.WriteLine("Added http Service endpoint...");
                    Console.WriteLine("Adding persistence and metadata behaviors...");
                    // Open service host.
                    wfServiceHost.Open();
                    Console.WriteLine("Started Equipment rental service...");
                    Console.WriteLine("Press [ENTER] to exit");

                    // Create a client that sends a message to create an instance of the workflow.
                    //IEquipmentRental client = ChannelFactory<IEquipmentRental>.CreateChannel(new BasicHttpBinding(), new EndpointAddress(hostAddress));
                    //var ret = client.CreateNewRental(new EquipmentRental
                    //{
                    //     RentalId = 1,
                    //     RentedEquipment = new Equipment{
                    //          EquipmentName="Backhoe",
                    //           RentalMinutes = 2,
                    //            DateRented=DateTime.Now
                    //     }
                    //});

                    Console.ReadLine();
                    wfServiceHost.Close();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
