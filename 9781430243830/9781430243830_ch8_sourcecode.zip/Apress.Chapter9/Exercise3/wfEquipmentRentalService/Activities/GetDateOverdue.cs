﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using wfEquipmentRentalService.Extensions;

namespace wfEquipmentRentalService.Activities
{
    public sealed class GetDateOverdue : CodeActivity
    {
        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            base.CacheMetadata(metadata);
            metadata.AddDefaultExtensionProvider(() => new DateOverdueExtension());
        }

        protected override void Execute(CodeActivityContext context)
        {
            DateOverdueExtension dateOverdueExtension = context.GetExtension<DateOverdueExtension>();
            Console.WriteLine(string.Format("Equipment became overdue on {0}",dateOverdueExtension.DateOverdue));
            
        }
    }
}
