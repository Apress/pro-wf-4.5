﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;

namespace wfEquipmentRentalService.Extensions
{
    public sealed class SetOverdueDate : CodeActivity
    {
        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            base.CacheMetadata(metadata);
            metadata.AddDefaultExtensionProvider(() => new DateOverdueExtension());
        }

        protected override void Execute(CodeActivityContext context)
        {
            DateOverdueExtension dateOverdueExtension = context.GetExtension<DateOverdueExtension>();
            dateOverdueExtension.SetDateOverDue();
        }
    }
}
