﻿using System;
using System.Activities.Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace wfEquipmentRentalService.Extensions
{
    public class DateOverdueExtension : PersistenceParticipant
    {
        static XNamespace DateOverdueNamespace = XNamespace.Get("urn:schemas-Apress:Chapter9/Persistence");
        static XName ParticipantName = DateOverdueNamespace.GetName("DateOverdue");

        public DateTime DateOverdue { get; set; }

        internal void SetDateOverDue()
        {
            DateOverdue = DateTime.Now;
        }

        protected override void CollectValues(out IDictionary<XName, object> readWriteValues, out IDictionary<XName, object> writeOnlyValues)
        {
            readWriteValues = new Dictionary<XName, object>(1) { { ParticipantName, DateOverdue } };
            writeOnlyValues = null;
        }

        protected override void PublishValues(IDictionary<XName, object> readWriteValues)
        {
            object loadedData;
            if (readWriteValues.TryGetValue(ParticipantName, out loadedData))
            {
                if (loadedData != null)
                    DateOverdue = Convert.ToDateTime(loadedData);
            }
        }
    }
}
