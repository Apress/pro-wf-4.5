﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Rental.DataModel;

using System.ServiceModel;

namespace ExternalClient
{
    [ServiceContract]
    public interface IEquipmentRental
    {
        [OperationContract(IsOneWay = false)]
        string CreateNewRental(EquipmentRental NewRental);
        [OperationContract(IsOneWay = false)]
        string RentalReturned(EquipmentRental CurrentRental);
        [OperationContract(IsOneWay = false)]
        string RentalReturnedLate(EquipmentRental LateRental);
    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private EquipmentRental BuildWorkflowArg()
        {
            EquipmentRental rental = null;
            try
            {
                if (cboEquipment.SelectedIndex > 0)
                {
                    rental = new EquipmentRental();
                    rental.RentedEquipment =
                        new Equipment
                        {
                            DateRented = DateTime.Now,
                            EquipmentName = cboEquipment.SelectedItem.ToString(),
                            RentalMinutes = Convert.ToInt32(cboRentalMinutes.SelectedItem)
                        };
                }
            }
            catch (Exception)
            {

                throw;
            }
            return rental;
        }

        private void cmdCreateRental_Click(object sender, EventArgs e)
        {
            try
            {
                var rental = BuildWorkflowArg();

                // Create a client that sends a message to create an instance of the workflow.
                IEquipmentRental client = ChannelFactory<IEquipmentRental>.CreateChannel(new BasicHttpBinding(), new EndpointAddress("http://localhost:8080/EquipmentRentalService"));

                rental.RentalId = 1;
                var ret = client.CreateNewRental(rental);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cmdReturnedRental_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a client that sends a message to create an instance of the workflow.
                IEquipmentRental client = ChannelFactory<IEquipmentRental>.CreateChannel(new BasicHttpBinding(), new EndpointAddress("http://localhost:8080/EquipmentRentalService"));
                 
                var ret = string.Empty;
                if(checkBox1.Checked)
                     ret = client.RentalReturnedLate(new EquipmentRental { RentalId = 1 });
                else
                    ret = client.RentalReturned(new EquipmentRental { RentalId = 1 });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
